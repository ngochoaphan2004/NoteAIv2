# NoteAI.v2 Backend Package
__version__ = "2.0.0"
